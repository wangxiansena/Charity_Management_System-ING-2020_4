<template>
<el-card>
 <router-link to="/notices/add">
    <el-button>
       发布公告
    </el-button>
 </router-link>
</el-card>
</template>