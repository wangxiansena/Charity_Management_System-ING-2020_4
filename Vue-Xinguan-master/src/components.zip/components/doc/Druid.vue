<template>

    <iframe src="https://www.zykhome.club:8081/druid/index.html" frameborder="no" border="0" marginwidth="0" marginheight="0"  allowtransparency="yes" style="overflow:hidden;" height="600px;" width="100%"></iframe>

</template>